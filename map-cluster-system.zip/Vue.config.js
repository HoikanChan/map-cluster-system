module.exports = {
  baseUrl: "./"
};
