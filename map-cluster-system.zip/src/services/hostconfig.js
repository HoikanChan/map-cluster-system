const baseHost = 'http://192.168.15.158:8099/';
const host = "http://192.168.15.158:8099/";
// 天津环境
// const host = "http://192.168.15.158:8099/rest/restForOutside/";
// 饶河环境
// const host = "http://192.168.15.158:8099/";
export default host;
